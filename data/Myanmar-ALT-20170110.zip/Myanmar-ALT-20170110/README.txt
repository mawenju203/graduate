Myanmar ALT

					Masao Utiyama
					Tue Jan 10 15:06:56 JST 2017

* Introduction

This is the Myanmar ALT of the Asian Language Treebank (ALT)
Corpus. Please refer to 
http://www2.nict.go.jp/astrec-att/member/mutiyama/ALT/index.html
for an introduction of the ALT project.

Myanmar ALT has been developed by NICT and UCSY. The license of
Maynmar ALT is

Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4
.0) License
https://creativecommons.org/licenses/by-nc-sa/4.0/


* Contents


Files extracted from annotated English-Myanmar ALT data

- data_my.en-raw : original English sentences
- data_my.my-raw : original Myanmar sentences

- data_my.en-tok : tokenized English sentences
- data_my.my-tok : tokenized Myanmar sentences
    # data_my.my-raw is actually tokenized.
    # "(" is replaces by -LRB- and ")" is replaced by -RRB- in data_my.my-tok.
    # replacing is also done for untokenized brackets, e.g., "(x" -> "-LRB-x".

- data_my.en-my  : token alignment between data_my.[en|my]-tok
    # Moses format, English token index - Myanmar token index, starting from 0.

- data_my.my-tag : POS tag for data_my.my-tok
- data_my.my-syn : syntactic tree for data_my.my-tok
    # unannotated tokens/constituents are marked by "?".
    # constituents are wrapped by "(" and ")", tags are attached after "(".

Error logs

- my.empty : index of empty lines in data_my.my-[raw|tok|syn]
- my-tag.error : index of lines with unmatched lengths in data_my.my-[tok|tag]
    # indice in data_my.en-my have been checked, no case of out of bounds.
    # brackets in data_my.my-syn have been checked, all well-paired.
